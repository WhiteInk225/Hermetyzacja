package org.example;
public class Main {
    public static void main(String[] args) {
        Car car1 = new Car("Toyota", 2022, 30000, 5, false);
        Car car2 = new Car("Ford", 2023, 35000, 7, true);
        Car car3 = new Car("Honda", 2021, 28000, 5, false);

        Motorcycle motorcycle1 = new Motorcycle("Harley Davidson", 2022, 25000, "Cruiser", false);
        Motorcycle motorcycle2 = new Motorcycle("Ducati", 2023, 30000, "Sport", true);
        Motorcycle motorcycle3 = new Motorcycle("Kawasaki", 2021, 22000, "Touring", false);

        Truck truck1 = new Truck("Volvo", 2022, 80000, 10, true);
        Truck truck2 = new Truck("Mercedes", 2023, 90000, 12, false);
        Truck truck3 = new Truck("Scania", 2021, 75000, 8, true);

        car1.displayCarInfo();
        car1.start();
        car1.accelerate();
        car1.brake();
        car1.stop();

        motorcycle2.displayMotorcycleInfo();
        motorcycle2.start();
        motorcycle2.wheelie();
        motorcycle2.ride();
        motorcycle2.stop();

        truck3.displayTruckInfo();
        truck3.start();
        truck3.loadCargo();
        truck3.unloadCargo();
        truck3.stop();
    }
    }
