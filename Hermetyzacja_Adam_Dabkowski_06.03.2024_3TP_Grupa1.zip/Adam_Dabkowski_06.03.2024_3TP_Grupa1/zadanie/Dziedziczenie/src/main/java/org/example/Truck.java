package org.example;

public class Truck extends Vehicle {
    private double cargoCapacity;
    private boolean hasTrailer;

    public Truck(String brand, int year, double price, double cargoCapacity, boolean hasTrailer) {
        super(brand, year, price);
        this.cargoCapacity = cargoCapacity;
        this.hasTrailer = hasTrailer;
    }

    public void loadCargo() {
        System.out.println(brand + " is loading cargo.");
    }

    public void unloadCargo() {
        System.out.println(brand + " is unloading cargo.");
    }

    public void displayTruckInfo() {
        System.out.println("Truck - Brand: " + brand + ", Year: " + year + ", Price: $" + price +
                ", Cargo Capacity: " + cargoCapacity + " tons, Has Trailer: " + hasTrailer);
    }
}