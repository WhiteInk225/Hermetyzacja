package org.example;

class Motorcycle extends Vehicle {
    private String type;
    private boolean hasSidecar;

    public Motorcycle(String brand, int year, double price, String type, boolean hasSidecar) {
        super(brand, year, price);
        this.type = type;
        this.hasSidecar = hasSidecar;
    }

    public void wheelie() {
        System.out.println(brand + " is doing a wheelie.");
    }

    public void ride() {
        System.out.println(brand + " is riding.");
    }

    public void displayMotorcycleInfo() {
        System.out.println("Motorcycle - Brand: " + brand + ", Year: " + year + ", Price: $" + price +
                ", Type: " + type + ", Has Sidecar: " + hasSidecar);
    }
}
