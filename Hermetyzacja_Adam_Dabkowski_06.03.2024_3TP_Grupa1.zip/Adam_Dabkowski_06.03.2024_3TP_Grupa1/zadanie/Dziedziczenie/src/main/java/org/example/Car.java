package org.example;

public class Car extends Vehicle {
    private int numberOfSeats;
    private boolean isConvertible;

    public Car(String brand, int year, double price, int numberOfSeats, boolean isConvertible) {
        super(brand, year, price);
        this.numberOfSeats = numberOfSeats;
        this.isConvertible = isConvertible;
    }

    public void accelerate() {
        System.out.println(brand + " is accelerating.");
    }

    public void brake() {
        System.out.println(brand + " is braking.");
    }

    public void displayCarInfo() {
        System.out.println("Car - Brand: " + brand + ", Year: " + year + ", Price: $" + price +
                ", Seats: " + numberOfSeats + ", Convertible: " + isConvertible);
    }
}
