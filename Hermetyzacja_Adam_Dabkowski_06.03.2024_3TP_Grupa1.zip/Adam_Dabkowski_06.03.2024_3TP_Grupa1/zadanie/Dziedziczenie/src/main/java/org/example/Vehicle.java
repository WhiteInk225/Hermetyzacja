package org.example;

public class Vehicle {
    public String brand;
    public int year;
    protected double price;
    private boolean isRunning;

    public Vehicle(String brand, int year, double price) {
        this.brand = brand;
        this.year = year;
        this.price = price;
        this.isRunning = false;
    }

    public void start() {
        if (!isRunning) {
            System.out.println(brand + " is starting.");
            isRunning = true;
        } else {
            System.out.println(brand + " is already running.");
        }
    }

    public void stop() {
        if (isRunning) {
            System.out.println(brand + " is stopping.");
            isRunning = false;
        } else {
            System.out.println(brand + " is already stopped.");
        }
    }

    public void displayInfo() {
        System.out.println("Brand: " + brand + ", Year: " + year + ", Price: $" + price);
    }
}
